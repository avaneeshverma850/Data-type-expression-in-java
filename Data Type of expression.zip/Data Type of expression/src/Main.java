
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
       /* byte x=5;
        int y=6;
        short z=8;
        float a= 65.4f+6;
        float b=5.5f+x;
        System.out.println(a);
        System.out.println(b);*/
        //Increment and Decrement Operators
        /*int i =56;
        System.out.println(i++);
        //first use i then after increment
        System.out.println(i);
        System.out.println(++i);
        System.out.println(i);
        //
        int j=67;
        int c=++j; // first j is increment then c is assigned j
        System.out.println(c);*/
        int y=7;
        int x=++y*8;
        System.out.println(x);
        char ch='a';
        System.out.println(++ch);


    }
}